#define BLYNK_TEMPLATE_ID "TMPL6WpE2NwPP"
#define BLYNK_TEMPLATE_NAME "Cloud Security Node"
#define BLYNK_PRINT Serial

#include <WiFi.h>
#include <BlynkSimpleEsp32.h>

char auth[] = "YOUR_BLYNK_AUTH_TOKEN";

char ssid[] = "Wokwi-GUEST";
char pass[] = "";

// Wokwi components
#define TRIG_PIN 5
#define ECHO_PIN 18
#define LED_PIN 2
#define BUZZER_PIN 4

BlynkTimer timer;

void sendTelemetry()
{
  // -----------------------------
  // Ultrasonic distance
  // -----------------------------

  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);

  digitalWrite(TRIG_PIN, LOW);

  long duration = pulseIn(ECHO_PIN, HIGH, 30000);

  float distance;

  if (duration == 0)
  {
    distance = 400;
  }
  else
  {
    distance = duration * 0.0343 / 2;
  }

  // -----------------------------
  // Simulated temperature/humidity
  // -----------------------------

  float temperature = random(200, 351) / 10.0;
  float humidity = random(400, 801) / 10.0;

  // -----------------------------
  // Simulated speed
  // -----------------------------

  float speed = random(0, 101);

  // -----------------------------
  // Security sensor
  // -----------------------------

  int sensorStatus = 0;
  int securityStatus = 0;

  // Object closer than 50 cm = detection
  if (distance < 50)
  {
    sensorStatus = 1;
    securityStatus = 1;

    digitalWrite(LED_PIN, HIGH);
    digitalWrite(BUZZER_PIN, HIGH);
  }
  else
  {
    sensorStatus = 0;
    securityStatus = 0;

    digitalWrite(LED_PIN, LOW);
    digitalWrite(BUZZER_PIN, LOW);
  }

  // -----------------------------
  // Send data to Blynk
  // -----------------------------

  Blynk.virtualWrite(V0, temperature);
  Blynk.virtualWrite(V1, humidity);
  Blynk.virtualWrite(V2, speed);
  Blynk.virtualWrite(V3, sensorStatus);
  Blynk.virtualWrite(V4, securityStatus);

  // -----------------------------
  // Serial Monitor
  // -----------------------------

  Serial.println("==========================");

  Serial.print("Distance: ");
  Serial.print(distance);
  Serial.println(" cm");

  Serial.print("Temperature: ");
  Serial.print(temperature);
  Serial.println(" °C");

  Serial.print("Humidity: ");
  Serial.print(humidity);
  Serial.println(" %");

  Serial.print("Speed: ");
  Serial.print(speed);
  Serial.println(" km/h");

  Serial.print("Sensor: ");

  if (sensorStatus == 1)
    Serial.println("DETECTED");
  else
    Serial.println("CLEAR");

  Serial.print("Security Status: ");

  if (securityStatus == 1)
    Serial.println("ALERT 🚨");
  else
    Serial.println("NORMAL ✅");
}

void setup()
{
  Serial.begin(115200);

  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  pinMode(LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  digitalWrite(LED_PIN, LOW);
  digitalWrite(BUZZER_PIN, LOW);

  randomSeed(micros());

  Serial.println("Starting Cloud Security Node...");

  Blynk.begin(auth, ssid, pass);

  timer.setInterval(3000L, sendTelemetry);
}

void loop()
{
  Blynk.run();
  timer.run();
}